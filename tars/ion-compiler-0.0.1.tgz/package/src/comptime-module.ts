import ts from "typescript";
import { Compiler } from "./compiler.js";
import { Module } from "./module.js";
import { ComptimeItem } from "./comptime.js";

export class ComptimeModule {
	public readonly module: Module;

	public get path() {
		return this.module.comptimePath;
	}

	public constructor(compiler: Compiler, module: Module) {
		this.module = module;
		this.compile(compiler);
	}

	public compile(compiler: Compiler) {
		const imports = this.resolveComptimeImports(compiler);
	}

	private resolveComptimeImports(compiler: Compiler): Map<string, ComptimeImport> {
		const imports = new Map<string, ComptimeImport>();
		this.module.sourceFile.statements.forEach(stmt => {
			if(ts.isImportDeclaration(stmt) && ts.isStringLiteral(stmt.moduleSpecifier)) {
				console.log(stmt.moduleSpecifier.text);
				// if its external, just resolve from one of the packages exports fields (or its main)
				// the symbols can be loaded trought the typechecker module.exports and iterating the names in the manifest.json
			}
		});
		return imports;
	}
}

export type ComptimeImport = {
	readonly declaration: ts.ImportDeclaration;
	readonly path: string;
	readonly comptimePath: string;
	readonly comptimeSymbols: Map<string, ComptimeItem>;
}